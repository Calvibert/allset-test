export default class Validator {
  static validateDict(dict) {
    const d = dict;
    var err = [];
    for (const [key, value] of Object.entries(d)) {
      if (value === "") {
        err.push(key);
        continue;
      }
      if (key === "email" && !this.validateEmail(value)) {
        err.push(key);
      }
    }
    return err;
  }

  static validateEmail(email) {
    var regex = /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,63}$/;
    return regex.test(String(email).toUpperCase());
  }
}
