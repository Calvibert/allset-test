import React, { Component } from "react";
import request from "request";
import Validator from "./validator";
import "./form.css";

export default class Form extends Component {
  constructor(props) {
    super(props);
    this.state = {
      error: [],
      email: "",
      age: "",
      gender: ""
    };

    this.handleChange = this.handleChange.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
  }

  handleChange(event, option = 0) {
    switch (option) {
      case "email":
        this.setState({ email: event.target.value });
        break;
      case "age":
        this.setState({ age: event.target.value });
        break;
      case "man":
      case "woman":
        this.setState({ gender: event.target.value });
        break;
      default:
        break;
    }
  }

  handleSubmit(event) {
    var e = Validator.validateDict(this.state);
    if (e.length > 0) {
      this.setState({ error: e });
      event.preventDefault();
      return;
    }
    delete this.state.error;
    this.setState({ error: [] });

    request.post("https://www.example.com", { form: this.state });
  }

  render() {
    return (
      <div className="form__div">
        <h1>Please fill in your information:</h1>
        <form onSubmit={this.handleSubmit} className="form__form">
          <div className="question__div">
            <label className="question__label">
              Email Address:
              <input
                className="question__input-text"
                type="text"
                id={this.state.error.includes("email") ? "error" : undefined}
                onChange={e => this.handleChange(e, "email")}
              />
            </label>
          </div>
          <div className="question__div">
            <label className="question__label">
              Age:
              <input
                className="question__input-number"
                type="number"
                id={this.state.error.includes("age") ? "error" : undefined}
                onChange={e => this.handleChange(e, "age")}
              />
            </label>
          </div>
          <div className="question__div">
            <label className="question__group-label">Gender:</label>
            <br />
            <label
              className="question__label"
              id={this.state.error.includes("gender") ? "error" : undefined}
            >
              Man
              <input
                className="question__input-radio"
                type="radio"
                name="gender"
                value="Man"
                onChange={e => this.handleChange(e, "man")}
                checked={this.state.man}
              />
            </label>
            <label
              className="question__label"
              id={this.state.error.includes("gender") ? "error" : undefined}
            >
              Woman
              <input
                className="question__input-radio"
                type="radio"
                name="gender"
                value="Woman"
                onChange={e => this.handleChange(e, "woman")}
              />
            </label>
          </div>
          <div
            className="button__div"
            id={this.state.error.length !== 0 ? "error-button" : undefined}
          >
            <input className="button__input" type="submit" value="Submit" />
          </div>
        </form>
      </div>
    );
  }
}
