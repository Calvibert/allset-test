import React from "react";
import { Switch, Route } from "react-router-dom";
import Form from "./questionnaire/form";
import FourOFour from "./general/404";

const Router = () => (
  <main>
    <Switch>
      <Route exact path="/" component={Form} />
      <Route path="/" component={FourOFour} />
    </Switch>
  </main>
);

export default Router;
