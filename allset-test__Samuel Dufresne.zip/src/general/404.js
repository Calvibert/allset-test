import React, { Component } from "react";
import { Link } from "react-router-dom";

class FourOFour extends Component {
  render() {
    return (
      <div>
        <h1>This page does not exist.</h1>
        <Link to="/">Back to the form</Link>
      </div>
    );
  }
}

export default FourOFour;
